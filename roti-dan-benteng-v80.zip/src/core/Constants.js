"use strict";

const arenaExtension = 464;

const Constants = {
  CANVAS_WIDTH: 576,
  WORLD_WIDTH: 576 + arenaExtension,
  CANVAS_HEIGHT: 247,
  GROUND_Y: 209,

  FARM: {
    cost: 1,
    hp: 40,
    homeX: 126,
    plots: [
      { x: 193, workX: 155 },
      { x: 265, workX: 227 }
    ],
    speed: 35,
    plantSeconds: 1.1,
    growthSeconds: 3.8,
    harvestSeconds: 1.2,
    deliverySeconds: 0.8,
    breadPerDelivery: 4
  },
  KNIGHT_COST: 2,
  SUMMON_COOLDOWN: 1.5,
  WIZARD_COST: 8,
  WIZARD_COOLDOWN: 5,
  KIRA_COST: 6,
  KIRA_COOLDOWN: 5,
  JAMES_COST: 4,
  JAMES_COOLDOWN: 4,
  LYNCE_COST: 5,
  LYNCE_COOLDOWN: 4.5,

  BASE_SKILL: {
    unlockChapterIndex: 1,
    duration: 10,
    cooldown: 60,
    moveSpeedMultiplier: 1.4,
    attackSpeedMultiplier: 1.3
  },

  DEFEND: {
    detectRange: 100,
    minX: 120,
    maxMarginFromEnemyBase: 40,
    groundToleranceTop: 34,
    groundToleranceBottom: 22,
    heroKinds: ["knight", "wizard", "kira", "james", "lynce"],
    formationBackOffsets: {
      knight: 0,
      james: 0,
      lynce: 65,
      wizard: 85,
      kira: 110
    },
    labels: {
      knight: "Ksatria",
      wizard: "Wizard",
      kira: "Kira",
      james: "James",
      lynce: "Lynce"
    },
    shortTags: {
      knight: "K",
      wizard: "W",
      kira: "R",
      james: "J",
      lynce: "L"
    },
    colors: {
      knight: "#6bc2a8",
      wizard: "#9e98f5",
      kira: "#7dd4f0",
      james: "#eab864",
      lynce: "#e88868"
    }
  },

  FIREBALL_SPEED: 220,
  FIREBALL_SPLASH: 5,
  FIREBALL_RADIUS: 34,

  KNIGHTS_PER_TARGET: 2,
  TROOP_DEPTHS: [0, 4, -3],

  BASES: {
    hero: { x: 109, hp: 360 },
    enemy: { x: 476 + arenaExtension, spawnX: 501 + arenaExtension, hp: 300 }
  },

  ASSETS: {
    sprites: {
      mountainRidge: "assets/sprites/background/mountain-ridge.png",
      rollingHills: "assets/sprites/background/rolling-hills.png",
      groundPath: "assets/sprites/background/ground-path.png",
      swamp: "assets/sprites/background/swamp.png",
      frost: "assets/sprites/background/frost.png",
      distantPine: "assets/sprites/background/cedar-distant.png",
      woodlandPine: "assets/sprites/background/cedar-woodland.png",
      woodlandOak: "assets/sprites/background/oak-woodland.png",
      autumnOak: "assets/sprites/background/oak-autumn.png",
      cloud: "assets/sprites/background/cloud.png",
      cloudWispy: "assets/sprites/background/cloud-wispy.png",
      swallow: "assets/sprites/background/swallow.png",
      farmer: "assets/sprites/units/farmer-v2.png",
      farmPlot: "assets/sprites/farm/plot.png",
      wheatSprout: "assets/sprites/farm/wheat-sprout.png",
      wheatRipe: "assets/sprites/farm/wheat-ripe.png",
      knight: "assets/sprites/units/knight.png",
      james: "assets/sprites/units/james.png",
      wizard: "assets/sprites/units/wizard.png",
      goblin: "assets/sprites/units/goblin.png",
      archer_goblin: "assets/sprites/units/archer-goblin.png",
      minotaur: "assets/sprites/units/minotaur.png",
      witcher: "assets/sprites/units/witcher.png",
      hollowMask: "assets/sprites/units/hollow-mask-animations.png",
      commander: "assets/sprites/units/commander.png",
      rootGiant: "assets/sprites/units/root-giant.png",
      frostGolem: "assets/sprites/units/frost-golem.png",
      frostGolemAnimation: "assets/sprites/units/frost-golem-animation.png",
      frostNova: "assets/sprites/effects/frost-nova-left.png",
      frostPrison: "assets/sprites/effects/frost-prison.png",
      commanderImpact: "assets/sprites/projectiles/commander-impact.png",
      witcherEffects: "assets/sprites/projectiles/witcher-effects.png",
      kira: "assets/sprites/units/kira-heal-plus.png",
      kiraPortrait: "assets/sprites/units/kira-barracks-fringe.png",
      lynce: "assets/sprites/units/lynce.png",
      lynceArrow: "assets/sprites/projectiles/lynce-arrow.png",
      lynceSkillArrow: "assets/sprites/projectiles/lynce-skill-arrow.png",
      fireball: "assets/sprites/projectiles/fireball.png",
      goblinBolt: "assets/sprites/projectiles/goblin-bolt.png",
      lightning: "assets/sprites/projectiles/lightning_kira.png",
      healingAura: "assets/sprites/projectiles/healing_kira.png",
      jamesShieldBash: "assets/sprites/effects/james-shield-bash.png",
      baseSpeedAura: "assets/sprites/effects/base-speed-aura.png",
      rootGiantRoots: "assets/sprites/projectiles/root-giant-roots.png"
    },
    sfx: {
      knight: "assets/sfx/knight-slash.wav",
      james: "assets/sfx/knight-slash.wav",
      baseSkill: "assets/sfx/base-skill.wav",
      lynceLaunch: "assets/sfx/lynce-launch.wav",
      lynceHit: "assets/sfx/lynce-hit.wav",
      lynceSkillLaunch: "assets/sfx/lynce-skill-launch.wav",
      lynceSkillHit: "assets/sfx/lynce-skill-hit.wav",
      fireball: "assets/sfx/fireball-explode.wav",
      lightningLaunch: "assets/sfx/lightning-launch.wav",
      lightning: "assets/sfx/lightning-impact.wav",
      heal: "assets/sfx/heal-receive.wav",
      commander: "assets/sfx/commander-attack.wav",
      commanderPlant: "assets/sfx/commander-plant.wav",
      commanderSweep: "assets/sfx/commander-sweep.wav",
      witcherLaunch: "assets/sfx/witcher-launch.wav",
      witcherImpact: "assets/sfx/witcher-impact.wav",
      witcherHeal: "assets/sfx/witcher-heal.wav",
      witcherSummonStart: "assets/sfx/witcher-summon-start.wav",
      witcherSummonComplete: "assets/sfx/witcher-summon-complete.wav",
      rootGiantAttack1: "assets/sfx/root-giant-attack1.wav",
      rootGiantAttack2: "assets/sfx/root-giant-attack2.wav",
      rootGiantSkill: "assets/sfx/root-giant-skill.wav"
    },
    bgm: {
      main: "assets/Back_sound/1.mp3",
      lobby: "assets/Back_sound/lobby.wav"
    }
  }
};

window.Constants = Constants;
